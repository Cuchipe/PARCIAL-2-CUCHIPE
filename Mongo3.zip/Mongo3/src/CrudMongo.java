import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoException;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import java.util.ArrayList;

public class CrudMongo {

    // Atributos para la conexión y la colección
    private MongoClient mongoClient;
    private MongoDatabase database;
    private MongoCollection<Document> collection;

    // Método para iniciar la conexión
    public void iniciarConexion() {
        try {
            mongoClient = new MongoClient("localhost", 27017);
            database = mongoClient.getDatabase("users");
            collection = database.getCollection("useradmin");
        } catch (MongoException e) {
            System.err.println("Error al iniciar la conexión: " + e.getMessage());
        }
    }

    // Método para leer datos de un usuario
    public String leerDatos(String nombreUsuario) {
        try {
            // Verificar si la colección existe antes de ejecutar la consulta
            if (collection != null) {
                BasicDBObject query = new BasicDBObject("name", nombreUsuario);
                try (MongoCursor<Document> cursor = collection.find(query)
                        .projection(new Document("pass", 1).append("_id", 0))
                        .iterator()) {

                    // Verificar si se encontró un documento
                    if (cursor.hasNext()) {
                        Document documento = cursor.next();
                        return documento.getString("pass");
                    } else {
                        System.err.println("Usuario no encontrado: " + nombreUsuario);
                    }
                }
            } else {
                System.err.println("La colección 'useradmin' no existe en la base de datos 'Usuarios'.");
            }
        } catch (MongoException e) {
            // Manejar excepciones de MongoDB
            System.err.println("Error al leer datos: " + e.getMessage());
        } catch (Exception e) {
            // Manejar otras excepciones
            System.err.println("Error general al leer datos: " + e.getMessage());
        }

        return null; // Devolver null si hay algún error o el usuario no se encuentra
    }

    // Método para cerrar la conexión
    public void cerrarConexion() {
        if (mongoClient != null) {
            mongoClient.close();
            System.out.println("Conexión cerrada correctamente.");
        }
    }
}
